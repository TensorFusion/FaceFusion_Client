#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 25 12:51:26 2025

@author: malom
"""

import cv2
import time
import os
import shutil
import pandas as pd
from typing import Optional, List
from pydantic import BaseModel
import numpy as np
import tempfile
from datetime import datetime
import face_recognition as recognizer
import shutil
import uuid
import face_recognition
from datetime import datetime
from pathlib import Path
    
from PIL import Image
from utils import *

from face_utils.monitor_faces_utils import FaceRecognizer, FaceRegManually, AverageFaceRecognizer
 
# FaceCaptureProcessor, FaceRecognitionExistingFaces, DirectoryMonitor, AverageFaceRecognizer

from face_utils.register_manual import register_manually

from db_utils import build_database
from config import *
from fastapi.responses import JSONResponse

# Assume this is your existing recognizer
#from average_face_recognizer import AverageFaceRecognizer  # Adjust as needed

# -------------------------------
# Initialization
# -------------------------------
ensure_directories()
init_log()
face_recognizer = FaceRecognizer()
face_reg_manual = FaceRegManually()


def register_from_ip_camera(ip_camera_url: str):
    
    print('Got it ....')
    
    cap = cv2.VideoCapture(ip_camera_url)
    if not cap.isOpened():
        raise HTTPException(status_code=500, detail="Unable to connect to the IP camera. Check URL and credentials.")

    frame_skip = 32  # Skip 4 frames, process every 5th
    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame.")
            break
    
        if frame_count % (frame_skip + 1) == 0:
            processed_frame = face_recognizer.process_frame(frame)
            # Optional: log or use the processed frame
            print("Processed frame at count:", frame_count)
            time.sleep(0.1)  # Optional pause
    
        frame_count += 1

    cap.release()
    return {"status": "Face data processed from IP camera stream."}


def face_recognition_live_view_from_ip(ip_camera_url: str):
    """
    Live face recognition from an IP camera using AverageFaceRecognizer.

    Args:
        ip_camera_url (str): URL of the IP camera stream.

    Returns:
        None (displays processed video frames in OpenCV window)
    """

    # Initialize recognizer
    recognizer = AverageFaceRecognizer(KNOWN_MULTI_FACES_PER_PERSON_DIR)

    # Open IP camera stream
    cap = cv2.VideoCapture(ip_camera_url)
    if not cap.isOpened():
        print(f"[ERROR] Failed to connect to IP camera: {ip_camera_url}")
        return

    print("[INFO] Starting face recognition. Press 'q' to quit.")

    frame_skip = 32  # Process every 17th frame
    frame_count = 0

    os.makedirs(UNKNOWN_FACE_DIR, exist_ok=True)

    while True:
        ret, frame = cap.read()
        if not ret:
            print("[WARNING] Failed to read frame from camera.")
            continue

        frame_count += 1
        if frame_count % frame_skip != 0:
            continue  # Skip this frame

        results = recognizer.recognize_faces_in_frame(frame)

        for res in results:
            top, right, bottom, left = res["box"]
            name = res["name"]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, (255, 255, 255), 2)

            if name == "Unknown":
                # Crop the face region
                face_img = frame[top:bottom, left:right]
                timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                filename = f"Unknown_{timestamp}.jpg"
                path = os.path.join(UNKNOWN_FACE_DIR, filename)
                cv2.imwrite(path, face_img)
                print(f"[INFO] Unknown face saved: {path}")

        # Show the annotated frame
        cv2.imshow("IP Camera Face Recognition", frame)

        # Press 'q' to exit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("[INFO] Exiting face recognition.")
            break

        time.sleep(0.03)

    cap.release()
    cv2.destroyAllWindows()
    

class LabelMetadata(BaseModel):
    actual_name: Optional[str]
    updated_name: Optional[str]
    email: Optional[str]
    phone: Optional[str]
    address: Optional[str]


# def update_known_face_labels(update_flag=False):
#     if not update_flag:
#         return print('Flag false')

#     known_faces_dir = "known_faces"
#     temp_face_dir = "known_faces_temp"
#     updated_dir = "known_faces_updated_labels"

#     os.makedirs(temp_face_dir, exist_ok=True)
#     os.makedirs(updated_dir, exist_ok=True)

#     # Step 1: Copy all face images to temp directory
#     # image_files = []
#     # for root, _, files in os.walk(known_faces_dir):
#     #     for f in files:
#     #         if f.lower().endswith((".jpg", ".jpeg", ".png")):
#     #             src_path = os.path.join(root, f)
#     #             rel_dir = os.path.relpath(root, known_faces_dir)
#     #             dst_dir = os.path.join(temp_face_dir, rel_dir)
#     #             os.makedirs(dst_dir, exist_ok=True)
#     #             dst_path = os.path.join(dst_dir, f)
#     #             shutil.copy(src_path, dst_path)
#     #             image_files.append((dst_path, f))

#     # if not image_files:
#     #     print("[!] No face images found in 'known_faces' directory.")
#     #     return
#     # else:
#     #     print(f"[✓] {len(image_files)} face images copied to temporary folder.")



#     # # Step 2: Ask user to relabel by the users
#     # existing_names = sorted({os.path.splitext(f[1])[0] for f in image_files})
#     # all_suggested_names = existing_names + ["Unknown"]

#     # labels_exist = [d for d in os.listdir(updated_dir) if os.path.isdir(os.path.join(updated_dir, d))]
#     # if ".DS_Store" in labels_exist:
#     #     labels_exist.remove(".DS_Store")
#     # labels_exist_with_nan = labels_exist + ["None"]

#     # person_metadata = []

#     # for img_path, img_file in image_files:
#     #     print(f"\n---\n[Image: {img_file}]")
#     #     current_name = os.path.splitext(img_file)[0]
#     #     print(f"Suggested label: {current_name}")
#     #     print("Available labels:", all_suggested_names)
#     #     new_name = input("Enter new label or press Enter to keep suggested: ").strip()
#     #     if not new_name:
#     #         new_name = current_name

#     #     print("Existing label folders:", labels_exist_with_nan)
#     #     actual_name_choice = input("Choose existing label folder or type 'None' to enter manually: ").strip()
#     #     if actual_name_choice == "None" or not actual_name_choice:
#     #         actual_name = input("Enter actual label name: ").strip()
#     #     else:
#     #         actual_name = actual_name_choice

#     #     email = input("Email: ").strip()
#     #     phone = input("Phone: ").strip()
#     #     address = input("Address: ").strip()

#     #     person_metadata.append({
#     #         "img_path": img_path,
#     #         "img_file": img_file,
#     #         "original_name": current_name,
#     #         "updated_name": new_name,
#     #         "actual_name": actual_name,
#     #         "email": email,
#     #         "phone": phone,
#     #         "address": address
#     #     })

#     # # Step 3: Apply label updates
#     # apply = input("\nApply label updates? (y/n): ").strip().lower()
#     # if apply != "y":
#     #     print("Label updates canceled.")
#     #     return

#     # renamed = []
#     # for entry in person_metadata:
#     #     old_path = entry["img_path"]
#     #     new_folder = entry["actual_name"] or entry["updated_name"]
#     #     new_dir = os.path.join(updated_dir, new_folder)
#     #     os.makedirs(new_dir, exist_ok=True)
#     #     new_path = os.path.join(new_dir, os.path.basename(old_path))
#     #     shutil.move(old_path, new_path)
#     #     renamed.append((old_path, new_path))

#     # if renamed:
#     #     print(f"[✓] {len(renamed)} files relabeled and moved!")

#     #     # Step 4: Update appearance log
#     #     try:
#     #         df_log = pd.read_csv("appearance_log.csv", names=["Name", "DateTime"])
#     #     except FileNotFoundError:
#     #         df_log = pd.DataFrame(columns=["Name", "DateTime"])

#     #     update_dict = {entry["original_name"]: entry["actual_name"] or entry["updated_name"]
#     #                    for entry in person_metadata}
#     #     df_log["UpdatedName"] = df_log["Name"].map(lambda x: update_dict.get(x, x))

#     #     df_log["Email"] = df_log["UpdatedName"].map(
#     #         lambda x: next((p["email"] for p in person_metadata
#     #                         if p["actual_name"] == x or p["updated_name"] == x), "NA"))
#     #     df_log["Phone"] = df_log["UpdatedName"].map(
#     #         lambda x: next((p["phone"] for p in person_metadata
#     #                         if p["actual_name"] == x or p["updated_name"] == x), "NA"))
#     #     df_log["Address"] = df_log["UpdatedName"].map(
#     #         lambda x: next((p["address"] for p in person_metadata
#     #                         if p["actual_name"] == x or p["updated_name"] == x), "NA"))

#     #     df_log.to_csv("appearance_log_updated_labels.csv", index=False)
#     #     print("[✓] Updated appearance log saved as 'appearance_log_updated_labels.csv'")
#     # else:
#     #     print("[!] No files were renamed.")
        
        
#     if not os.path.exists(TEMP_FACE_DIR):
#         return JSONResponse(content={"error": "Temporary face directory not found."}, status_code=404)

#     image_paths = []
#     for fname in os.listdir(TEMP_FACE_DIR):
#         if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
#             full_path = os.path.join(TEMP_FACE_DIR, fname)
#             image_paths.append(full_path)

#     return JSONResponse(content={"images": image_paths}, status_code=200)


def update_known_face_labels(update_flag=False):
    if not update_flag:
        return print('Flag false')
        
    if not os.path.exists(TEMP_FACE_DIR):
        return JSONResponse(content={"error": "Temporary face directory not found."}, status_code=404)

    image_paths = []
    for fname in os.listdir(TEMP_FACE_DIR):
        if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
            full_path = os.path.join(TEMP_FACE_DIR, fname)
            image_paths.append(full_path)

    return JSONResponse(content={"images": image_paths}, status_code=200)

