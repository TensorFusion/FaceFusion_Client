#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 25 17:57:10 2025

@author: malom
"""

from fastapi import FastAPI, Query, Request, File, UploadFile
from fastapi.responses import JSONResponse
import cv2
import time
from typing import Optional
from face_api import register_from_ip_camera, update_known_face_labels, face_recognition_live_view_from_ip
import numpy as np
import file
app = FastAPI()
from face_utils.monitor_faces_utils import FaceRecognizer, FaceRegManually, AverageFaceRecognizer
face_recognizer = FaceRecognizer()


# API_KEY = "9999999999"

# @app.middleware("http")
# async def auth(request: Request, call_next):
#     if request.headers.get("x-api-key") != API_KEY:
#         return JSONResponse(status_code=401, content={"detail": "Unauthorized"})
#     return await call_next(request)

@app.get("/")
def root():
    return {"message": "Face Recognition API is running."}


@app.get("/register/{ip_camera_url}")
def register_faces(ip_camera_url: str): # = Query(..., description="IP camera RTSP URL")):
    try:
        functional_ip = "rtsp://Tapocam:Tapocam123@"+ip_camera_url+"/stream1"
        print('Found camera IP :', functional_ip)
        register_from_ip_camera(functional_ip)
        return {"status": "Started registration from IP camera."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.get("/update/{flag}")
def update_labels(flag: bool):
    try:
        result = update_known_face_labels(flag)
        print(result)
        
        return {"status": "Update complete.", "details": result}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
    
@app.get("/recognize/{ip_camera_url}")
def recognize_faces(ip_camera_url: str): # = Query(..., description="IP camera RTSP URL")):
    try:
        functional_ip = "rtsp://Tapocam:Tapocam123@"+ip_camera_url+"/stream1"
        print('Found camera IP :', functional_ip)
        face_recognition_live_view_from_ip(functional_ip)
        return {"status": "Started face recognition from IP camera."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
    
    
##Added API for getting feed as frame 
@app.post("/face-reg")
async def recognize_single_frame(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        results = face_recognizer.recognize_faces_in_frame(frame)
        return {"results": results}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
    