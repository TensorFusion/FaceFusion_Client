import os
import cv2
import uuid
import time
import pandas as pd
import streamlit as st
from datetime import datetime
from typing import Tuple

def detect_faces(frame) -> Tuple:
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    face_crops = []
    for (x, y, w, h) in faces:
        face_crop = frame[y:y+h, x:x+w]
        face_crops.append(face_crop)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
    return frame, face_crops

def register_manually():
    base_dir = "registered_faces"
    os.makedirs(base_dir, exist_ok=True)

    # Initialize session state variables
    for key in ["name", "address", "email", "cell", "recording", "video_capture", "person_dir", "log_data"]:
        if key not in st.session_state:
            st.session_state[key] = "" if key in ["name", "address", "email", "cell"] else None

    st.title("📝 Manual Face Registration")

    # New Registration button
    if st.button("➕ New Registration"):
        for key in ["name", "address", "email", "cell", "person_dir", "log_data"]:
            st.session_state[key] = "" if key in ["name", "address", "email", "cell"] else None
        st.session_state["recording"] = False

    # Input fields
    st.session_state.name = st.text_input("Full Name", st.session_state.name)
    st.session_state.address = st.text_input("Address", st.session_state.address)
    st.session_state.email = st.text_input("Email Address", st.session_state.email)
    st.session_state.cell = st.text_input("Cell Number", st.session_state.cell)

    # Start Recording
    if not st.session_state.recording and st.button("▶️ Start Recording"):
        st.session_state.recording = True
        unique_id = str(uuid.uuid4())[:8]
        person_dir = os.path.join(base_dir, f"{st.session_state.name}_{unique_id}")
        os.makedirs(person_dir, exist_ok=True)
        st.session_state.person_dir = person_dir
        st.session_state.log_data = []
        st.session_state.video_capture = cv2.VideoCapture(0)
        st.success("Recording started...")

    FRAME_WINDOW = st.empty()

    # Live feed and capture logic
    if st.session_state.recording and st.session_state.video_capture:
        ret, frame = st.session_state.video_capture.read()
        if ret:
            frame_with_boxes, face_crops = detect_faces(frame)
            FRAME_WINDOW.image(cv2.cvtColor(frame_with_boxes, cv2.COLOR_BGR2RGB), channels="RGB")

            # Capture face
            if st.button("📸 Capture Face"):
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                for idx, face_img in enumerate(face_crops):
                    filename = f"{timestamp}_face_{idx}.jpg"
                    filepath = os.path.join(st.session_state.person_dir, filename)
                    cv2.imwrite(filepath, face_img)
                    st.session_state.log_data.append({
                        "Name": st.session_state.name,
                        "Address": st.session_state.address,
                        "Email": st.session_state.email,
                        "Cell": st.session_state.cell,
                        "Image": filename,
                        "Timestamp": timestamp
                    })
                st.success(f"Saved {len(face_crops)} face(s).")

            # Stop Recording
            if st.button("🛑 Stop Recording"):
                st.session_state.recording = False
                if st.session_state.video_capture:
                    st.session_state.video_capture.release()
                    st.session_state.video_capture = None

                # Save per-person CSV
                if st.session_state.log_data:
                    df = pd.DataFrame(st.session_state.log_data)
                    csv_path = os.path.join(st.session_state.person_dir, "log.csv")
                    df.to_csv(csv_path, index=False)

                # Merge all logs
                all_logs = []
                for folder in os.listdir(base_dir):
                    log_path = os.path.join(base_dir, folder, "log.csv")
                    if os.path.exists(log_path):
                        all_logs.append(pd.read_csv(log_path))
                if all_logs:
                    pd.concat(all_logs).to_csv(os.path.join(base_dir, "all_logs.csv"), index=False)

                st.success("Recording stopped and logs saved.")
                st.info("Click '➕ New Registration' to register another person.")
        else:
            st.warning("⚠️ Failed to read from camera.")