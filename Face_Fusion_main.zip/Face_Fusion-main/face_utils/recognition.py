#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 08:29:52 2025

@author: malom
"""

# recognition.py

import cv2
import face_recognition
import numpy as np
from datetime import datetime
from config import FACES_DIR, SNAPSHOT_DIR, CENTER_ID
from utils import load_known_faces, log_appearance
import os

class FaceRecognizer:
    def __init__(self):
        self.known_encodings, self.known_names = load_known_faces()
        self.appearance_counts = {name: 0 for name in self.known_names}
        self.appeared_set = set()

    def get_frequent_names(self, min_count=5):
        return [name for name, count in self.appearance_counts.items() if count >= min_count]

    def get_appearance_counts(self):
        return self.appearance_counts

    def save_new_face(self, encoding, face_img, name=None):
        if name is None:
            name = f"person_{len(self.known_names)+1}"
        filename = f"{name}.jpg"
        path = os.path.join(FACES_DIR, filename)
        cv2.imwrite(path, face_img)
        self.known_encodings.append(encoding)
        self.known_names.append(name)
        self.appearance_counts[name] = 1
        return name

    def process_frame(self, frame):
        rgb_small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(rgb_small_frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = face_recognition.compare_faces(self.known_encodings, face_encoding, tolerance=0.5)
            name = "Unknown"
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if True in matches:
                match_index = matches.index(True)
                name = self.known_names[match_index]
                self.appearance_counts[name] += 1
            else:
                top, right, bottom, left = [v * 4 for v in face_location]
                face_img = frame[top:bottom, left:right]
                name = self.save_new_face(face_encoding, face_img)

            log_appearance(name, timestamp, self.appeared_set)

            # Draw bounding box
            top, right, bottom, left = [v * 4 for v in face_location]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, f"{name} ({self.appearance_counts[name]})", (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        return frame
    
