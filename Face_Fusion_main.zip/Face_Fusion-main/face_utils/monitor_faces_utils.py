#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul  9 22:25:39 2025

@author: malom
"""

import os
import face_recognition
import cv2
import tempfile
import numpy as np
from pathlib import Path
import uuid
from datetime import datetime
from config import * #FACES_DIR, SNAPSHOT_DIR, CENTER_ID
from utils import load_known_faces, log_appearance
import os

class FaceRecognizer:
    def __init__(self):
        self.known_encodings, self.known_names = load_known_faces()
        self.appearance_counts = {name: 0 for name in self.known_names}
        self.appeared_set = set()

    def get_frequent_names(self, min_count=5):
        return [name for name, count in self.appearance_counts.items() if count >= min_count]

    def get_appearance_counts(self):
        return self.appearance_counts

    def save_new_face(self, encoding, face_img, name=None):
        if name is None:
            name = f"person_{len(self.known_names)+1}"
        filename = f"{name}.jpg"
        path = os.path.join(FACES_DIR, filename)
        cv2.imwrite(path, face_img)
        self.known_encodings.append(encoding)
        self.known_names.append(name)
        self.appearance_counts[name] = 1
        return name

    def process_frame(self, frame):
        rgb_small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(rgb_small_frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = face_recognition.compare_faces(self.known_encodings, face_encoding, tolerance=0.5)
            name = "Unknown"
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if True in matches:
                match_index = matches.index(True)
                name = self.known_names[match_index]
                self.appearance_counts[name] += 1
            else:
                top, right, bottom, left = [v * 4 for v in face_location]
                face_img = frame[top:bottom, left:right]
                name = self.save_new_face(face_encoding, face_img)

            log_appearance(name, timestamp, self.appeared_set)

            # Draw bounding box
            top, right, bottom, left = [v * 4 for v in face_location]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, f"{name} ({self.appearance_counts[name]})", (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        return frame

from typing import Tuple, List

def process_frame_and_extract_faces(frame) -> Tuple[np.ndarray, List[np.ndarray]]:
    """
    Detects faces in the frame, draws rectangles, and returns cropped face images.
    
    Returns:
        - frame_with_boxes: Frame with rectangles drawn around faces
        - face_crops: List of cropped face images
    """
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    face_locations = face_recognition.face_locations(rgb_frame)

    face_crops = []
    frame_with_boxes = frame.copy()

    for (top, right, bottom, left) in face_locations:
        # Draw bounding box
        cv2.rectangle(frame_with_boxes, (left, top), (right, bottom), (0, 255, 0), 2)

        # Crop and save face
        face_crop = frame[top:bottom, left:right]
        face_crops.append(face_crop)

    return frame_with_boxes, face_crops

class FaceCaptureProcessor:
    def __init__(self):
        pass

    def process_frame_and_extract_faces(self, frame) -> Tuple[np.ndarray, List[np.ndarray]]:
        """
        Detects faces in the frame, draws rectangles, and returns cropped face images.
        """
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_frame)

        face_crops = []
        frame_with_boxes = frame.copy()

        for (top, right, bottom, left) in face_locations:
            cv2.rectangle(frame_with_boxes, (left, top), (right, bottom), (0, 255, 0), 2)
            face_crop = frame[top:bottom, left:right]
            face_crops.append(face_crop)

        return frame_with_boxes, face_crops
    

class FaceRegManually:
    def __init__(self):
        self.known_encodings, self.known_names = load_known_faces()
        self.appearance_counts = {name: 0 for name in self.known_names}
        self.appeared_set = set()

    def get_frequent_names(self, min_count=5):
        return [name for name, count in self.appearance_counts.items() if count >= min_count]

    def get_appearance_counts(self):
        return self.appearance_counts

    def save_new_face(self, encoding, face_img, img_path, name=None):
        #if name is None:
            #name = f"person_{len(self.known_names)+1}"
           # name = f"person_{len(self.known_names)+1}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:4]}"
        #filename = f"{name}.jpg"
        #path = os.path.join(saving_path, filename)
        cv2.imwrite(img_path, face_img)
        self.known_encodings.append(encoding)
        self.known_names.append(name)
        self.appearance_counts[name] = 1
        return name

    def process_frame(self, frame, img_path):
        rgb_small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(rgb_small_frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = face_recognition.compare_faces(self.known_encodings, face_encoding, tolerance=0.5)
            name = "Unknown"
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if True in matches:
                match_index = matches.index(True)
                name = self.known_names[match_index]
                self.appearance_counts[name] += 1
            else:
                top, right, bottom, left = [v * 4 for v in face_location]
                face_img = frame[top:bottom, left:right]
                #name = self.save_new_face(face_encoding, face_img, img_path)
                
                cv2.imwrite(img_path, face_img)
                self.known_encodings.append(face_encoding)
                self.known_names.append(name)
                self.appearance_counts[name] = 1

            log_appearance(name, timestamp, self.appeared_set)

            # Draw bounding box
            top, right, bottom, left = [v * 4 for v in face_location]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, f"{name} ({self.appearance_counts[name]})", (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        return frame 
    
    


class FaceRecognitionExistingFaces:
    def __init__(self):
        self.known_face_encoding = None
        self.known_face_name = "Target Person"
        self.alerted = False

    def load_face_image(self, file):
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as tmp_file:
            tmp_file.write(file.read())
            tmp_path = tmp_file.name
        image = face_recognition.load_image_file(tmp_path)
        encodings = face_recognition.face_encodings(image)
        if encodings:
            self.known_face_encoding = encodings[0]
            return True, "Face encoding loaded successfully."
        else:
            return False, "No face found in the image."

    def recognize_from_frame(self, frame):
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        #rgb_small = small_frame[:, :, ::-1]
        rgb_small = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small)
        face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

        result_flag = False
        matches_found = []

        #for face_encoding in face_encodings:
        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = face_recognition.compare_faces([self.known_face_encoding], face_encoding)
            
            name = "Unknown"
            
            # if matches[0]:
            #     result_flag = True
            #     #return True
            
            if True in matches:
                index = matches.index(True)
                name = self.known_names[index]
                if name not in self.alerted:
                    self.alerted.add(name)
                    matches_found.append(name)

            # Scale back up since the frame was downscaled
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            # Draw rectangle and name on the original frame
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.rectangle(frame, (left, bottom - 30), (right, bottom), (0, 255, 0), cv2.FILLED)
            cv2.putText(frame, name, (left + 6, bottom - 6),
                        cv2.FONT_HERSHEY_DUPLEX, 0.6, (0, 0, 0), 1)

        return frame, matches_found
        #return result_flag, face_locations
    
    
class DirectoryMonitor:
    def __init__(self, directory="monitor_faces"):
        self.directory = directory
        self.known_encodings = []
        self.known_names = []
        self.alerted = set()
        self.load_faces()

    def load_faces(self):
        self.known_encodings = []
        self.known_names = []

        for filename in os.listdir(self.directory):
            if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                path = os.path.join(self.directory, filename)
                image = face_recognition.load_image_file(path)
                encodings = face_recognition.face_encodings(image)
                if encodings:
                    self.known_encodings.append(encodings[0])
                    name = os.path.splitext(filename)[0]
                    self.known_names.append(name)
                else:
                    print(f"[WARN] No face found in {filename}")

    def recognize_from_frame(self, frame):
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        small_frame = cv2.resize(rgb_frame, (0, 0), fx=0.25, fy=0.25)

        face_locations = face_recognition.face_locations(small_frame)
        face_encodings = face_recognition.face_encodings(small_frame, face_locations)

        matches_found = []

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = face_recognition.compare_faces(self.known_encodings, face_encoding, tolerance=0.5)
            name = "Unknown"

            if True in matches:
                index = matches.index(True)
                name = self.known_names[index]
                if name not in self.alerted:
                    self.alerted.add(name)
                    matches_found.append(name)

            # Scale back up since the frame was downscaled
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            # Draw rectangle and name on the original frame
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.rectangle(frame, (left, bottom - 30), (right, bottom), (0, 255, 0), cv2.FILLED)
            cv2.putText(frame, name, (left + 6, bottom - 6),
                        cv2.FONT_HERSHEY_DUPLEX, 0.6, (0, 0, 0), 1)

        return frame, matches_found
    

class AverageFaceRecognizer:
    def __init__(self, known_faces_dir):
        self.known_faces_dir = known_faces_dir
        self.known_encodings = []
        self.known_names = []
        self._load_average_encodings()

    def save_new_face(self, face_img, name=None):
        if name is None:
            name = f"person_{len(self.known_names)+1}"
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        full_name = name+'_'+timestamp
        filename = f"{full_name}.jpg"
        path = os.path.join(UNKNOWN_FACE_DIR, filename)
        cv2.imwrite(path, face_img)
      
        #return name
    
    def _load_average_encodings(self):
        for person_dir in Path(self.known_faces_dir).iterdir():
            if person_dir.is_dir():
                encodings = []
                for img_file in person_dir.glob("*.*"):
                    img = face_recognition.load_image_file(img_file)
                    face_locations = face_recognition.face_locations(img)
                    if len(face_locations) == 0:
                        continue
                    face_encoding = face_recognition.face_encodings(img, known_face_locations=face_locations)[0]
                    encodings.append(face_encoding)

                if encodings:
                    average_encoding = np.mean(encodings, axis=0)
                    self.known_encodings.append(average_encoding)
                    self.known_names.append(person_dir.name)

    def recognize_faces_in_frame(self, frame):
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        results = []

        for face_encoding, face_location in zip(face_encodings, face_locations):
            distances = face_recognition.face_distance(self.known_encodings, face_encoding)
            best_match_index = np.argmin(distances) if len(distances) > 0 else None
            name = "Unknown"
            if best_match_index is not None and distances[best_match_index] < 0.5:
                name = self.known_names[best_match_index]
            else:
                name = "Unknown"

            top, right, bottom, left = face_location
            face_img = frame[top:bottom, left:right]
            
            if name == "Unknown":
                self.save_new_face(face_img)
                print("Unknown face saved ....")
                
            results.append({
                    "name": name,
                    "box": (top, right, bottom, left)
                })
                

        return results
    
    
    
    