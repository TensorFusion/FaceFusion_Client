#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul  9 15:59:20 2025

@author: malom
"""
# face_recognition_streamlit.py
import cv2
import numpy as np
import face_recognition
import tempfile

class FaceRecognitionExistingFaces:
    def __init__(self):
        self.known_face_encoding = None
        self.known_face_name = "Target Person"
        self.alerted = False

    def load_face_image(self, file):
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as tmp_file:
            tmp_file.write(file.read())
            tmp_path = tmp_file.name
        image = face_recognition.load_image_file(tmp_path)
        encodings = face_recognition.face_encodings(image)
        if encodings:
            self.known_face_encoding = encodings[0]
            return True, "Face encoding loaded successfully."
        else:
            return False, "No face found in the image."

    def recognize_from_frame(self, frame):
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        #rgb_small = small_frame[:, :, ::-1]
        rgb_small = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small)
        face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

        result_flag = False
        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces([self.known_face_encoding], face_encoding)
            if matches[0]:
                result_flag = True
                #return True
        return result_flag, face_locations