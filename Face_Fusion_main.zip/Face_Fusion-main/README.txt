# Face API Server (FastAPI)

## How to Run

1. Install dependencies:
   pip install -r requirements.txt

2. Start the server:
   uvicorn main:app --host 0.0.0.0 --port 8000

3. Call the API:
   curl -H "x-api-key: your-secret-key" "http://localhost:8000/recognize?ip=your_rtsp_stream_url"
