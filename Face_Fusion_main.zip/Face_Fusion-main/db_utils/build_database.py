#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 10 07:23:59 2025

@author: malom
"""

import os
import csv
import pandas as pd
from datetime import datetime
from pathlib import Path

# Simulate lookup for demo purposes
def simulate_web_lookup(name):
    dummy_data = {
        "alice": {"full_name": "Alice Smith", "email": "alice@example.com", "phone": "123-456-7890", "address": "123 Main St, NY"},
        "bob": {"full_name": "Bob Johnson", "email": "bob@company.com", "phone": "987-654-3210", "address": "456 Maple Ave, CA"},
    }
    return dummy_data.get(name.lower(), {
        "full_name": "NA", "email": "NA", "phone": "NA", "address": "NA"
    })

def build_person_database(known_dir="known_faces", log_file="person_logs.csv", out_csv="person_database.csv"):
    # Get known face filenames
    face_files = [f for f in os.listdir(known_dir) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
    seen_names = set()

    # Optionally read appearance logs
    if os.path.exists(log_file):
        log_df = pd.read_csv(log_file, names=["Name", "DateTime", "CenterID"])
        seen_names = set(log_df["Name"].unique())

    records = []

    for face_file in face_files:
        label_name = Path(face_file).stem
        if label_name in seen_names:
            person_info = simulate_web_lookup(label_name)
            records.append({
                "face_filename": face_file,
                "label_name": label_name,
                "full_name": person_info["full_name"],
                "email": person_info["email"],
                "phone": person_info["phone"],
                "address": person_info["address"],
                "last_seen": log_df[log_df["Name"] == label_name]["DateTime"].max()
            })
        else:
            records.append({
                "face_filename": face_file,
                "label_name": label_name,
                "full_name": "NA",
                "email": "NA",
                "phone": "NA",
                "address": "NA",
                "last_seen": "NA"
            })

    # Save to CSV
    df = pd.DataFrame(records)
    df.to_csv(out_csv, index=False)
    print(f"[INFO] Person database saved to {out_csv}")