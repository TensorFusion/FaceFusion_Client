#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 08:28:45 2025

@author: malom
"""

# utils.py

import os
import cv2
import csv
import numpy as np
import pandas as pd
from datetime import datetime
import requests


#from config import FACES_DIR, LOG_FILE, SNAPSHOT_DIR, SNAPSHOT_FORMAT
from config import * #FACES_DIR, LOG_FILE, SNAPSHOT_DIR, SNAPSHOT_FORMAT, CENTER_ID, CENTRAL_API_URL, KNOWN_MULTI_FACES_PER_PERSON_DIR

# Create necessary directories


def ensure_directories():
    os.makedirs(FACES_DIR, exist_ok=True)
    os.makedirs(SNAPSHOT_DIR, exist_ok=True)
    os.makedirs(KNOWN_MULTI_FACES_PER_PERSON_DIR,exist_ok=True)
    os.makedirs(UNKNOWN_FACE_DIR,exist_ok=True)
    os.makedirs(TEMP_FACE_DIR,exist_ok=True)
    os.makedirs(CENTER_ID,exist_ok=True)

# Initialize appearance log if not exists

def init_log():
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Name', 'DateTime'])

# Load face encodings and names from known_faces folder

def load_known_faces():
    encodings = []
    names = []
    for file in os.listdir(FACES_DIR):
        if file.endswith(('.jpg', '.png')):
            path = os.path.join(FACES_DIR, file)
            image = cv2.imread(path)
            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            import face_recognition
            face_encs = face_recognition.face_encodings(rgb)
            if face_encs:
                encodings.append(face_encs[0])
                names.append(os.path.splitext(file)[0])
    return encodings, names
    #return names

# Log appearance if it's not already logged

def log_appearance(name, timestamp, appeared_set):
    if name not in appeared_set:
        with open(LOG_FILE, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([name, timestamp])
        appeared_set.add(name)

# Get unique names from logs

def get_logged_names():
    if not os.path.exists(LOG_FILE):
        return []
    with open(LOG_FILE, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader, None)
        return sorted(set(row[0] for row in reader))

# Retrieve logs for a specific person

def get_logs_for_person(name):
    if not os.path.exists(LOG_FILE):
        return []
    logs = []
    with open(LOG_FILE, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader, None)
        for row in reader:
            if row[0] == name:
                logs.append(row)
    return logs

# Find saved face image for a person

def find_face_image(name):
    for ext in ('.jpg', '.png'):
        path = os.path.join(FACES_DIR, f"{name}{ext}")
        if os.path.exists(path):
            return path
    return None

# Get appearance count per day

def get_daily_counts():
    if not os.path.exists(LOG_FILE):
        return pd.DataFrame(columns=['Date', 'Count'])
    dates = []
    with open(LOG_FILE, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader, None)
        for row in reader:
            dt = row[1].split()[0]
            dates.append(dt)
    if not dates:
        return pd.DataFrame(columns=['Date', 'Count'])
    df = pd.Series(dates).value_counts().reset_index()
    df.columns = ['Date', 'Count']
    return df.sort_values('Date')

# Draw appearance chart

def draw_appearance_chart(counts_dict):
    if not counts_dict:
        return None
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots()
    names = list(counts_dict.keys())
    counts = list(counts_dict.values())
    ax.barh(names, counts, color='skyblue')
    ax.set_xlabel("Appearances")
    ax.set_title("Face Appearance Count")
    fig.tight_layout()
    return fig

# Upload logs to central server

# def upload_logs_to_server():
#     try:
#         with open(LOG_FILE, 'rb') as f:
#             files = {'file': (LOG_FILE, f, 'text/csv')}
#             data = {'center_id': CENTER_ID}
#             response = requests.post(CENTRAL_API_URL, data=data, files=files)
#         return response.status_code == 200
#     except Exception as e:
#         print(f"[ERROR] Upload failed: {e}")
#         return False


def upload_logs_to_server():
    try:
        if not os.path.exists(LOG_FILE):
            print(f"[ERROR] Log file not found: {LOG_FILE}")
            return False

        with open(LOG_FILE, 'rb') as f:
            files = {'file': (os.path.basename(LOG_FILE), f, 'text/csv')}
            data = {'center_id': CENTER_ID}
            print(f"[INFO] Uploading to {CENTRAL_API_URL} with center_id={CENTER_ID}")
            response = requests.post(CENTRAL_API_URL, data=data, files=files)
            print(f"[INFO] Server response: {response.status_code} {response.text}")
            return response.status_code == 200
    except Exception as e:
        print(f"[ERROR] Upload failed: {e}")
        return False
    