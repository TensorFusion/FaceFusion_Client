#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 08:30:49 2025

@author: malom
"""

# config.py

# App settings
APP_TITLE = "Face Recognition Center App"
WEBCAM_SOURCE = 0  # 0 for default webcam

# File paths
FACES_DIR = "known_faces"
LOG_FILE = "appearance_log.csv"

TEMP_FACE_DIR = "known_faces_temp"
UNKNOWN_FACE_DIR = "unknown_faces"

KNOWN_MULTI_FACES_PER_PERSON_DIR = "known_faces_updated_labels"
LOG_UPDATED_FILE = "appearance_log_updated_labels.csv"

CSV_LOG_DIR = "csv_lgs"

SNAPSHOT_DIR = "snapshots"

# Snapshot settings
YDT_FORMAT = "%Y%m%d_%H%M%S"

# Unique Center ID (change this for each center)
CENTER_ID = "center_01"

# Central server settings (for uploads)
CENTRAL_API_URL = "http://your-central-server/upload"
CENTRAL_API_KEY = "your-api-key-here"  # Optional for security

# Alert threshold
FREQUENT_VISITOR_THRESHOLD = 5
MULTI_CENTER_ALERT_THRESHOLD = 5  # Number of centers
MULTI_CENTER_ALERT_WINDOW_HOURS = 6  # Time window in hours