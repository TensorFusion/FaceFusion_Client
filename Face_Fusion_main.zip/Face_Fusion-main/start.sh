#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 03:06:42 2025

@author: malom
"""

#!/bin/bash

uvicorn face_api:app --host 0.0.0.0 --port 10000